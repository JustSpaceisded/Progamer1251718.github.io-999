# M64js
Welcome, to the full SM64 JavaScript port! <br>
With full saving capabilites and HD textures, you'll have a blast!

# Controls:
Movement: Arrow Keys <br>
A: X <br>
B: C <br>
R: Q <br>
Z: Space <br>
Start: Enter <br>
C-stick: WASD
